package com.paymenttcp;

import org.junit.jupiter.api.Test;

class PaymentTcpApplicationTests {

    @Test
    void contextLoads() {
    }

}
